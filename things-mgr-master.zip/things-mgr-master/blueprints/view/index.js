module.exports = {
  description () {
    return 'generates a view component';
  }
};
